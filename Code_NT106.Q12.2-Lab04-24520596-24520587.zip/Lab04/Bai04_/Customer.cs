﻿namespace Bai04_.Models
{
    public class Customer
    {
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
    }
}